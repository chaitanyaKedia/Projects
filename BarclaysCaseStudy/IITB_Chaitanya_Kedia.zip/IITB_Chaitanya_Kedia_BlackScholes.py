import sys
import math
from scipy.stats import norm

class options:
  def __init__(self,inp):

      self.spot=int(inp[0])
      self.strike=int(inp[1])
      self.t=int(inp[2])
      self.i_vol=int(inp[3])/100
      self.nature=inp[4]
      self.r=int(inp[5])/100
      self.d=int(inp[6])/100

      global div,free

      div=math.e**(-self.d*self.t)
      free=math.e**(-self.r*self.t)
      denom=self.i_vol*math.sqrt(self.t)

      self.d1=(math.log(self.spot/self.strike,math.e)+self.t*(self.r-self.d+0.5*self.i_vol**2))/denom
      self.d2=self.d1-denom
      
  def call(self):
            val = round(self.spot*div*norm.cdf(self.d1)- self.strike*free*norm.cdf(self.d2),2)
            return val
    
  def put(self):
            val =  round(self.strike*free*norm.cdf(-self.d2)-self.spot*div*norm.cdf(-self.d1),2)
            return val


contract=options(sys.argv[1].split(','))

if contract.nature.lower()=="call":
    print(contract.call())
elif contract.nature.lower()=="put":
    print(contract.put())
