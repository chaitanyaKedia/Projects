1.There are two python scripts- one for Black Scholes and other for Monte   Carlo method.Also the VBA code is attached as two txt files.
2.The VBA macros have the "Python.exe" path and the scripts path as per my   laptop. So you need to change the path according to your computer which I   have commented in the VBA code.




Assumptions in Monte Carlo Simulation-

1.Stock Prices follow a geometric Brownian motion.
2.We assume ln(S_T) to be the function of the stochastic process while   applying ito's lemma.[S_T is the stock price at time T]
3.B_T(the random component of Brownian motion) follows N(0,T) but for     modelling purpose we will model it as N(0,1)*sqrt(T)