import numpy as np
import sys
import math

class options:
  def __init__(self,inp):

      self.spot=int(inp[0])
      self.strike=int(inp[1])
      self.t=int(inp[2])
      self.i_vol=int(inp[3])/100
      self.nature=inp[4]
      self.r=int(inp[5])/100
      self.d=int(inp[6])/100
      
  def call(self):
            rand_nums=np.random.randn(10000000)
            S_T=self.spot*(math.e**(((self.r-self.d-0.5*(self.i_vol**2))*self.t + self.i_vol*rand_nums*math.sqrt(self.t))))
            val=np.maximum(S_T-self.strike,0)
            ca=(math.e**(-self.r*self.t))*np.mean(val)
            return round(ca,2)
    
  def put(self):
            rand_nums=np.random.randn(10000000)
            S_T=self.spot*(math.e**(((self.r-self.d-0.5*(self.i_vol**2))*self.t + self.i_vol*rand_nums*math.sqrt(self.t))))
            val=np.maximum(self.strike-S_T,0)    
            pu=(math.e**(-self.r*self.t))*np.mean(val)
            return round(pu,2)


contract=options(sys.argv[1].split(','))

if contract.nature.lower()=="call":
    print(contract.call())
elif contract.nature.lower()=="put":
    print(contract.put())
